from kivy.utils import platform
if platform == 'android':
    from jnius import autoclass, cast

    def get_location():
        Context = autoclass('android.content.Context')
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        activity = PythonActivity.mActivity
        LocationManager = autoclass('android.location.LocationManager')
        location_service = activity.getSystemService(Context.LOCATION_SERVICE)
        provider = LocationManager.GPS_PROVIDER
        location = location_service.getLastKnownLocation(provider)
        if location:
            return location.getLatitude(), location.getLongitude()
        return None, None
else:
    def get_location():
        return None, None
