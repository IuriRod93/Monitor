# 📱 PLANO DE INTEGRAÇÃO DJANGO + KIVY + VPS

## ✅ TAREFAS CONCLUÍDAS
- [x] Análise do código existente
- [x] Identificação dos endpoints e configurações
- [x] Planejamento da integração
- [x] Atualizar endpoints no app Kivy para IP da VPS (147.79.111.118:8000)
- [x] Implementar captura automática de screenshots a cada 1 minuto
- [x] Adicionar captura de screenshots quando usuário acessar redes sociais

## 🔄 TAREFAS PENDENTES

### 3. Atualizar Permissões Android
- [ ] Modificar Spy-mobile/buildozer.spec com permissões necessárias
- [ ] Adicionar SYSTEM_ALERT_WINDOW para screenshots
- [ ] Verificar compatibilidade com Android moderno

### 4. Criar Sistema de Deploy na VPS
- [ ] Criar script deploy_vps.sh para SSH + build APK
- [ ] Configurar ambiente Android na VPS
- [ ] Automatizar transferência do APK gerado

### 5. Testes e Validação
- [ ] Testar comunicação Django ↔ Kivy
- [ ] Verificar upload de screenshots
- [ ] Validar permissões Android
- [ ] Testar deploy completo na VPS

## 📋 DETALHES TÉCNICOS

**IP da VPS:** 147.79.111.118
**Porta Django:** 8000
**Acesso:** root@147.79.111.118

**Funcionalidades implementadas:**
- Screenshots automáticos (1 min + redes sociais)
- Upload para Django via API
- Interface atualizada com status de captura
- Limpeza automática de arquivos temporários

**Arquivos principais:**
- Spy-mobile/main.py
- Spy-mobile/buildozer.spec
- Spy/monitoramento/views.py (já tem API upload)
